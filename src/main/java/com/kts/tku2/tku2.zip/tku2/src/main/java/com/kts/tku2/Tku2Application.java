package com.kts.tku2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tku2Application {

    public static void main(String[] args) {
        SpringApplication.run(Tku2Application.class, args);
    }

}
