package com.kts.tku2.data.repository;

import com.kts.tku2.data.entity.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorRepository extends JpaRepository <Professor, Long> {
}
