package com.kts.tku2.data.entity;

import lombok.*;

import javax.persistence.*;

// 과목 엔티티
@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Table(name="course")
public class Course extends BaseEntity{

    // 과목 번호
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 과목명
    @Column(nullable = false)
    private String name;

    // 수업 요일
    @Column(nullable = false)
    private String day;

    // 학점
    @Column(nullable = false)
    private Integer grades;

    // 수업 시작 시간
    @Column(nullable = false)
    private Integer start_time;

    // 수업 종료 시간
    @Column(nullable = false)
    private Integer end_time;

    // 총 수강인원
    @Column(nullable = false)
    private Integer personnel;

    // 과목 주요 설명 null 값 허용
    @Column(nullable = true)
    private String comment;

    @ManyToOne
    @JoinColumn(name="pro_id")
    @ToString.Exclude
    private Professor professor;
}
